This module should be supported in both Joomla 2.x and 3.x
It was tested in versions 2.5.19 and 3.2.3.

Installation should be a basic extension installation, no configuration or setup is necessary.
Once installed you should see a new module type called 'Content Syndication'.  

Instances of this module allow you to select public health content from various sources
to add to your pages.  Begin by selecting an appropriate source, filter the results with the 
various fields in the module admin, and then select a content title.  You can see a preview of the content
when editing the module in the administrator site.  You can control some settings for how the content
is displayed using advanced module settings.
